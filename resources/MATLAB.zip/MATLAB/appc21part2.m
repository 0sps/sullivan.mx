clear all
clc
fprintf ('\n************************************************') 
fprintf ('\n* Name:     Sean Sullivan       Date: 10/08/19 *') 
fprintf ('\n* Seat: 17  File: APP_C21_1                    *') 
fprintf ('\n* Instructor:                      Morin 10:20 *') 
fprintf ('\n************************************************')


tic;

% Setting Variables for 1E3
x=0;
y=0;
unC=0;
ovC=0;
xTest=0;
yTest=0;
pt1=0;
sqSim=0;
sqAct=0;
pcntErr=0;

% Setting up a for loop for 1E3

for k=1:1:1000
    
    
    x=1+rand();
    y=rand();
    
    xTest=.25/x;
    yTest=y^2;
    
    if yTest<= xTest
        unC=unC+1;
    else
        ovC=ovC+1;
    end
    
    
end

pt1=unC/k;
sqSim=pt1+1;
sqAct=sqrt(2);

% Calculating percent error for 1E3
pt1=abs(sqAct-sqSim);
pcntErr=pt1/sqAct;
pctErr=pcntErr*100;

fprintf('\nFor 1E3, %f was the simulated sqrt(2) value, and %f is the percent error.',sqSim,pctErr);

g(1,1)=sqSim;
g(1,2)=pctErr;

% Getting time for simulation
time1(3)=toc;



tic;
% Setting Variables for 1E4
x=0;
y=0;
unC=0;
ovC=0;
xTest=0;
yTest=0;
pt1=0;
sqSim=0;
sqAct=0;
pcntErr=0;

% Setting up a for loop for 1E4

for k=1:1:10000
    
    
    x=1+rand();
    y=rand();
    
    xTest=.25/x;
    yTest=y^2;
    
    if yTest<= xTest
        unC=unC+1;
    else
        ovC=ovC+1;
    end
    
    
end

pt1=unC/k;
sqSim=pt1+1;
sqAct=sqrt(2);

% Calculating percent error for 1E4
pt1=abs(sqAct-sqSim);
pcntErr=pt1/sqAct;
pctErr=pcntErr*100;

fprintf('\nFor 1E4, %f was the simulated sqrt(2) value, and %f is the percent error.',sqSim,pctErr);

g(2,1)=sqSim;
g(2,2)=pctErr;

% Getting time for simulation
time1(4)=toc;


tic;
% Setting Variables for 1E5
x=0;
y=0;
unC=0;
ovC=0;
xTest=0;
yTest=0;
pt1=0;
sqSim=0;
sqAct=0;
pcntErr=0;

% Setting up a for loop for 1E5

for k=1:1:100000
    
    
    x=1+rand();
    y=rand();
    
    xTest=.25/x;
    yTest=y^2;
    
    if yTest<= xTest
        unC=unC+1;
    else
        ovC=ovC+1;
    end
    
    
end

pt1=unC/k;
sqSim=pt1+1;
sqAct=sqrt(2);

% Calculating percent error for 1E5
pt1=abs(sqAct-sqSim);
pcntErr=pt1/sqAct;
pctErr=pcntErr*100;

fprintf('\nFor 1E5, %f was the simulated sqrt(2) value, and %f is the percent error.',sqSim,pctErr);

g(3,1)=sqSim;
g(3,2)=pctErr;

% Getting time for simulation
time1(5)=toc;



tic;
% Setting Variables for 1E6
x=0;
y=0;
unC=0;
ovC=0;
xTest=0;
yTest=0;
pt1=0;
sqSim=0;
sqAct=0;
pcntErr=0;

% Setting up a for loop for 1E6

for k=1:1:1000000
    
    
    x=1+rand();
    y=rand();
    
    xTest=.25/x;
    yTest=y^2;
    
    if yTest<= xTest
        unC=unC+1;
    else
        ovC=ovC+1;
    end
    
    
end

pt1=unC/k;
sqSim=pt1+1;
sqAct=sqrt(2);

% Calculating percent error for 1E6
pt1=abs(sqAct-sqSim);
pcntErr=pt1/sqAct;
pctErr=pcntErr*100;

fprintf('\nFor 1E6, %f was the simulated sqrt(2) value, and %f is the percent error.',sqSim,pctErr);

g(4,1)=sqSim;
g(4,2)=pctErr;

% Getting time for simulation
time1(6)=toc;



tic;
% Setting Variables for 1E7
x=0;
y=0;
unC=0;
ovC=0;
xTest=0;
yTest=0;
pt1=0;
sqSim=0;
sqAct=0;
pcntErr=0;

% Setting up a for loop for 1E7

for k=1:1:10000000
    
    
    x=1+rand();
    y=rand();
    
    xTest=.25/x;
    yTest=y^2;
    
    if yTest<= xTest
        unC=unC+1;
    else
        ovC=ovC+1;
    end
    
    
end

pt1=unC/k;
sqSim=pt1+1;
sqAct=sqrt(2);

% Calculating percent error for 1E7
pt1=abs(sqAct-sqSim);
pcntErr=pt1/sqAct;
pctErr=pcntErr*100;

fprintf('\nFor 1E7, %f was the simulated sqrt(2) value, and %f is the percent error.',sqSim,pctErr);

g(5,1)=sqSim;
g(5,2)=pctErr;


% Getting time for simulation
time1(7)=toc;


tic;
% Setting Variables for 1E8
x=0;
y=0;
unC=0;
ovC=0;
xTest=0;
yTest=0;
pt1=0;
sqSim=0;
sqAct=0;
pcntErr=0;

% Setting up a for loop for 1E8
for k=1:1:100000000
    
    
    x=1+rand();
    y=rand();
    
    xTest=.25/x;
    yTest=y^2;
    
    if yTest<= xTest
        unC=unC+1;
    else
        ovC=ovC+1;
    end
    
    
end

pt1=unC/k;
sqSim=pt1+1;
sqAct=sqrt(2);

% Calculating percent error for 1E8
pt1=abs(sqAct-sqSim);
pcntErr=pt1/sqAct;
pctErr=pcntErr*100;

fprintf('\nFor 1E8, %f was the simulated sqrt(2) value, and %f is the percent error.',sqSim,pctErr);

g(6,1)=sqSim;
g(6,2)=pctErr;

% Getting time for simulation
time1(8)=toc;


tic;
% Setting Variables for 1E9
x=0;
y=0;
unC=0;
ovC=0;
xTest=0;
yTest=0;
pt1=0;
sqSim=0;
sqAct=0;
pcntErr=0;

% Setting up a for loop for 1E9
for k=1:1:1000000000
    
    
    x=1+rand();
    y=rand();
    
    xTest=.25/x;
    yTest=y^2;
    
    if yTest<= xTest
        unC=unC+1;
    else
        ovC=ovC+1;
    end
    
    
end

pt1=unC/k;
sqSim=pt1+1;
sqAct=sqrt(2);

% Calculating percent error for 1E9
pt1=abs(sqAct-sqSim);
pcntErr=pt1/sqAct;
pctErr=pcntErr*100;

fprintf('\nFor 1E9, %f was the simulated sqrt(2) value, and %f is the percent error.',sqSim,pctErr);

g(7,1)=sqSim;
g(7,2)=pctErr;

% Getting time for simulation
time1(9)=toc;

% Setting the timePlot variable so as to display time values in the print
% statement
timePlot = [time1(3),time1(4),time1(5),time1(6),time1(7),time1(8),time1(9)];

% Printing!
fprintf('\n\nThe amount of seconds it took to run each simulation, 1E3 through 1E9 respectively, is shown below:\n%f\n%f\n%f\n%f\n%f\n%f\n%f',timePlot(1),timePlot(2),timePlot(3),timePlot(4),timePlot(5),timePlot(6),timePlot(7));

%  \ \ \ \ \ \ \ \
%
%  Time to plot! \
%
%  \ \ \ \ \ \ \ \

coordPairs = [1000,10000,100000,1000000,10000000,100000000,1000000000];

semilogx(coordPairs,g(:,1),'--');
figure
semilogx(coordPairs,g(:,2),':');
figure
loglog(coordPairs,timePlot,'-o');

