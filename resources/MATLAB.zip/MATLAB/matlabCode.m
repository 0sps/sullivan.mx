%Materials Testing Script File - Updated 10/18/19 

clear; clc; close all;

%This script file was created as an example for the Materials Testing Lab
%From carmen.osu.edu


%The data is loaded into two variables, time and newtons, through xlsread.
time = xlsread('Aerodynamics.xlsx','Dyman','A1:A17250');
newtons = xlsread('Aerodynamics.xlsx','Dyman','C1:C17250');

%Using MATLAB's matrix arithmetic to subtract a y-offset found after
%initial plot of the data. 
newtons = newtons - 3.66;


%plotting the final data
plot (time, newtons, 'r');
xlabel('Time (s)');
ylabel('Thrust (N)');
