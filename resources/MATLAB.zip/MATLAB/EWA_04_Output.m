%EWA04



% Story #1 print to screen.  You must copy this statement and modify it
% to also print to an output file.

fprintf('\n\nOne %s autumn morning, %s took a/an %s for a walk. \nBecause %s was late for %s, he/she %s \nall the way to the %s. On the way there %s passed\nthrough the %s where he/she saw a/an %s, but excited Brutus. \n%s also saw a large, %s group of %s, playing %s.\nWhen  %s arrived at the %s, he/she realized it was Friday\nand he/she didn''t have %s today.\n\n',adjective1, name1, animal, name1, activity_class, past_tense_verb1, place, name1,place_on_OSU_campus, adjective2, name1, adjective3, plural_noun1, game_sport, name1, place, activity_class)

fprintf('Thanks for playing! Please enter a filename to save this story:\n');
filename=input(':','s');


    
% Story #2 print to screen.  You must copy this statement and modify it
% to also print to an output file.
fprintf('\n\nIn a/an %s galaxy not unlike ours, on a/an %s planet not \nunlike this one, there live a/an %s but curious group of %s.  \nEach of them are required to %s with a %s everyday, and if \nanyone forgets they are publicly shamed for their %s insubordination.  \nOne day, %s forgot this duty and decided to %s instead of \ntaking his/her punishment.  Obviously, the rest of the %s were \n%s and %s by his/her actions. There were not enough \n%s on the entire %s planet or in the %s \ngalaxy to excuse %s of his/her actions.  %s had no choice but to \n%s.  Surprisingly this was enough to gain %s the forgiveness of \nhis/her %s who eventually convinced the colony of %s \nto %s  %s. Needless to say, things either turned out good \nor bad for %s; it all depends on perspective.\n\n',adjective1, adjective2, adjective3, plural_noun1, present_verb1, noun1, adjective4, name1, present_verb2, plural_noun1, adjective5, adjective6, plural_noun2,adjective2,adjective1,name1,name1,verb1,name1,family_member1, plural_noun1, present_verb3,name1,name1)

fprintf('Thanks for playing! Please enter a filename to save this story:\n');
filename=input(':','s');



% Story #3 print to screen.  You must copy this statement and modify it
% to also print to an output file.
fprintf('\n\nOnce upon a time there was a/an %s %s who sought the aid of a/an\n%s %s to help her escape from the dreadful %s\nshe has been locked in for the past %s %s. Finally after\nseveral newspaper ads and a couple of smoke signals the %s \n%s %s his way past the fire breathing dragon, through the \n%s foot deep moat, and up the %s tower.  At last the %s \n%s was saved and the couple was free to live %s ever after.\n\n',adjective1,occupation1,adjective2,occupation2,type_of_shelter,number1,unit_of_time,adjective2,occupation2,present_verb1,number2,adjective3,adjective1,occupation1,adverb)

fprintf('Thanks for playing! Please enter a filename to save this story:\n');
filename=input(':','s');
