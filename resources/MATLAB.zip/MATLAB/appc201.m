fprintf ('\n************************************************') 
fprintf ('\n* Name:     Sean Sullivan       Date: 10/08/19 *') 
fprintf ('\n* Seat: 17  File: APP_C20_1                    *') 
fprintf ('\n* Instructor:                      Morin 10:20 *') 
fprintf ('\n************************************************')


pressure=load('APP_C20_1_Press_Unfiltered.txt');

% Extracting time and pressure vectors from the matrix
time=pressure(:,1);
pres=pressure(:,2);

% Setting variables to 0 before loop
tC=0;
presCorrected=0;
timeC=0;

% Setting up a for loop that plots a new graph of corrected data
for p=1:1:2801
    if pres(p) <= 1000
        timeC=timeC+1;
        tC(timeC)=time(p);
        presCorrected(timeC)=pres(p);
    end
    
end
   
% Opening data file to print
file=fopen('APP_C20_1_Press_Filtered.txt','w');

% Starting for loop to print filtered data to data file
for j=1:1:timeC
    
fprintf(file,'%f\t%f\n',tC(j),presCorrected(j));

end

% Calculating lengths
lengthT=length(time);
lengthP=length(pres);
lengthTC=length(tC);
lengthPC=length(presCorrected);

% Determining the amt of filtered data points
filtered=lengthT-lengthTC;

% Finding relevant statistics
originalStd=std(pres);
originalMean=mean(pres);
originalMedian=median(pres);
filteredStd=std(presCorrected);
filteredMean=mean(presCorrected);
filteredMedian=median(presCorrected);


fprintf('\n\nThe original data file had a pressure mean of %f, median of %f, and standard deviation of %f.',originalMean, originalMedian, originalStd);

fprintf('\nThe filtered data file had a pressure mean of %f, median of %f, and standard deviation of %f.',filteredMean, filteredMedian, filteredStd);
fprintf('\nThe original dataset had %i values. The filtered data set had %i values, or %i fewer values than the original set.',p,timeC,filtered);

% Plotting the filtered graph
plot(time,pres,'.');
hold on
plot(tC,presCorrected);
hold off




