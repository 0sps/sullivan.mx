% Clear MATLAB workspace memory of all variables and clear the
% Command Window
clear all
clc
% $CODE$: Modify fprintf commands as appropriate
fprintf ('\n')
fprintf ('\n************************************************')
fprintf ('\n* Name: Sean Sullivan Date: 01/04/01 *')
fprintf ('\n* Seat: 00 File: MATLAB_A_TEMP_TEST.m *')
fprintf ('\n* Instructor: Morin 10:20 *')
fprintf ('\n************************************************')
fprintf ('\n')
% Load data file into matrix called thermistor
thermistor = load('MATLAB_A_THERM.dat');
minutes = thermistor(:,1);
% $CODE$: Extract the second column of data (resistance at
% CPU)from thermistor and store it in a vector.
resistance = thermistor(:,2);
% Set constants for Steinhart-Hart equation
A = 0.00093238;
B = 0.00022151;
C = 0.00000012607;

% $CODE$: Extract the third column of data (system
% temperature)from thermistor and store it in a vector.
temp = thermistor(:,3);
% $CODE$: Use the Steinhart-Hart equation provided in the problem
% statement to find the temperatures for the thermistor at the
% CPU. Use vector math and store this result in a vector. The
% constants A, B,and C are defined earlier in the script file.
logR = log(resistance);

pt1 = (B*logR);
pt2 = C.*(logR).^3;

calcTem = (A + pt1 + pt2);
calcTeem = 1 ./ calcTem;

for i=1:1:104
    calcTemp(i) = calcTeem(i) - 273.15;
end



% $CODE$: Use one of MATLAB's built-in functions to find the maximum
% temperature at the CPU. Display the value to the screen,
% ensuring the value is properly identified.
maxTemp = max(calcTemp);
fprintf('\nThe maximum temperature at the CPU was %f',maxTemp);
% $CODE$: Use a selection structure to print the appropriate messages
% to the screen, as described in the problem statement
if maxTemp >= 72
    fprintf('\nThe maximum temperature has exceeded the limit.');
end
if maxTemp >= 68 && maxTemp < 72
    fprintf('\nThe maximum temperature approached the limit.');
end
if maxTemp < 68
    fprintf('\nThe maximum temperature was safe.');
end
% $CODE$: Use MATLAB's built in functions to find the average
% temperature at the CPU and print it to the screen, ensuring
% the value is properly identified.
meanTemp = mean(calcTemp,'all');
fprintf('\n\nThe average CPU temperature was %f',meanTemp);
% $CODE$: Determine how many times the calculated CPU temperature was
% less than the measured system temperature. Print this value
% and the total number of times temperatures were measured,
% formatted as shown in the problem statement.
lessThanMeasured = 0;
len = length(temp);

for k=1:1:104
    if calcTemp(k) < temp(k)
    lessThanMeasured = lessThanMeasured + 1;
    end
end
fprintf('\n The CPU temperature was less than the system temperature %i times.',lessThanMeasured);
fprintf('\nThere were %.0f measurements.',len);