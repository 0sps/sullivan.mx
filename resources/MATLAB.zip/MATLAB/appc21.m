clear all
clc
fprintf ('\n************************************************') 
fprintf ('\n* Name:     Sean Sullivan       Date: 10/08/19 *') 
fprintf ('\n* Seat: 17  File: APP_C21_1                    *') 
fprintf ('\n* Instructor:                      Morin 10:20 *') 
fprintf ('\n************************************************')

x=0;
y=0;
unC=0;
ovC=0;
xTest=0;
yTest=0;
pt1=0;
sqSim=0;
sqAct=0;
pcntErr=0;

for k=1:1:1000000
    
    
    x=1+rand();
    y=rand();
    
    xTest=.25/x;
    yTest=y^2;
    
    if yTest<= xTest
        unC=unC+1;
    else
        ovC=ovC+1;
    end
    
    
end

% Calculating square root
pt1=unC/1000000;
sqSim=pt1+1;
sqAct=sqrt(2);

% Calculating percent error
pt1=abs(sqAct-sqSim);
pcntErr=pt1/sqAct;
pctErr=pcntErr*100;

fprintf('\n%f was the simulated sqrt(2) value, and %f is the percent error.',sqSim,pctErr);




