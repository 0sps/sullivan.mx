[time1]=xlsread('DAQSheet.xlsx','A0_Data','A2:A10001');
[amp1]=xlsread('DAQSheet.xlsx','A0_Data','B2:B10001');
[time2]=xlsread('DAQSheet.xlsx','A0_Data','C2:C10001');
[amp2]=xlsread('DAQSheet.xlsx','A0_Data','D2:D10001');

plot(time1,amp1);
hold on;
plot(time1,amp2);
hold off;


