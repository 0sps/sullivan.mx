function user = getresp(x)
fprintf('\n\nPlease enter %s.',x);
user=input('\nEnter Here: ','s');

end
