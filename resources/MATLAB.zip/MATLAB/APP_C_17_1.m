fprintf ('\n************************************************') 
fprintf ('\n* Name:     Sean Sullivan       Date: 10/03/19 *') 
fprintf ('\n* Seat: 17  File: APP_C17_1.m                  *') 
fprintf ('\n* Instructor:                      Morin 10:20 *') 
fprintf ('\n************************************************')

% Loading the data files into vectors

g1=load('APP_C17_1_Gas_1.txt');
g2=load('APP_C17_1_Gas_2.txt');
g3=load('APP_C17_1_Gas_3.txt');
g4=load('APP_C17_1_Gas_4.txt');
g5=load('APP_C17_1_Gas_5.txt');

% Plugging the data into the function "combust" by using the filename of
% the function.

gas1 = APP_C_17_1_Combust(g1);
gas2 = APP_C_17_1_Combust(g2);
gas3 = APP_C_17_1_Combust(g3);
gas4 = APP_C_17_1_Combust(g4);
gas5 = APP_C_17_1_Combust(g5);

% Setting up variables for loop to calculate total energy value
gas1e=0;
gas2e=0;
gas3e=0;
gas4e=0;
gas5e=0;

% Finding the actual total energy values through a loop
for g=1:1:4
    gas1e = gas1e + gas1(g);
end
for g=1:1:4
    gas2e = gas2e + gas2(g);
end
for g=1:1:4
    gas3e = gas3e + gas3(g);
end
for g=1:1:4
    gas4e = gas4e + gas4(g);
end
for g=1:1:4
    gas5e = gas5e + gas5(g);
end

% Printing out all energy values
fprintf('Gas mixture 1 had a total energy value of %f kJ/mol,\nGas mixture 2 had a total energy value of %f kJ/mol,\nGas mixture 3 had a total energy value of %f kJ/mol,\nGas mixture 4 had a total energy value of %f kJ/mol,\nand gas mixture 5 had a total energy value of %f kJ/mol.\n',gas1e,gas2e,gas3e,gas4e,gas5e);


% Printing out values that were over 7000 kJ/mol.
fprintf('\nAdditionally,\n');
if gas1e >= 7000
    fprintf('\nThe value of gas mixture 1 was over 7000 kJ/mol.');
end

if gas2e >= 7000
    fprintf('\nThe value of gas mixture 2 was over 7000 kJ/mol.');
end

if gas3e >= 7000
    fprintf('\nThe value of gas mixture 3 was over 7000 kJ/mol.');
end

if gas4e >= 7000
    fprintf('\nThe value of gas mixture 4 was over 7000 kJ/mol.');
end

if gas5e >= 7000
    fprintf('\nThe value of gas mixture 5 was over 7000 kJ/mol.');
end








