fprintf ('\n************************************************') 
fprintf ('\n* Name:     Sean Sullivan       Date: 09/16/19 *') 
fprintf ('\n* Seat: 17  File: APP_C11_1.m                  *') 
fprintf ('\n* Instructor:                      Morin 10:20 *') 
fprintf ('\n************************************************')

% Asking the user for input
deg=input('\nHello! Please input the temperature in degrees Celcius.\n');

% Doing conversions
F=((deg*(9/5))+32);
N=(deg*(33/100));
K=(deg+273.15);
Re=(deg*(4/5));
R=((deg+273.15)*(9/5));
Ro=(deg*(21/40)+7.5);
De=((100-deg)*(3/2));

% Alerting the user to their value and its conversions
fprintf('You entered %i �C which converts to: \n%i �N \n%i �F \n%i �R� \n%i �De \n%i �R� \n%i K \n%i R',deg,N,F,Ro,De,Re,K,R);

% Printing converted values to a file by loading a new file and writing
Converted=fopen('Conversions.dat','w');
fprintf(Converted,'%i\n',F);
fprintf(Converted,'%i\n',N);
fprintf(Converted,'%i\n',K);
fprintf(Converted,'%i\n',Re);
fprintf(Converted,'%i\n',Ro);
fprintf(Converted,'%i\n',R);
fprintf(Converted,'%i\n',De);

%Getting the reative humidity
RH=input('\nPlease enter the relative humidity.');

%Calculating the dewpoint
a=17.271
b=237.7
ytrh = ((a*deg)+(log(RH/100)));

dewpoint=((b*ytrh)/(a-ytrh));

%Telling the user
fprintf('With %i �C as the temperature, %i as the relative humidity, and constants a and b as %i and %i, respectively, I found a dewpoint of %f.',deg,RH,a,b,dewpoint);

%Printing to the file
fprintf(Converted,'With %i �C as the temperature, %i as the relative humidity, and constants a and b as %i and %i, respectively, I found a dewpoint of %f ',deg,RH,a,b,dewpoint);
fprintf('�C');

