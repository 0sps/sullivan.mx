fprintf ('\n************************************************') 
fprintf ('\n* Name:     Sean Sullivan       Date: 10/03/19 *') 
fprintf ('\n* Seat: 17  File: APP_C18_1.m                  *') 
fprintf ('\n* Instructor:                      Morin 10:20 *') 
fprintf ('\n************************************************')


% loading the variables
mass=load('APP_C18_1_mass.txt');
inRad=load('APP_C18_1_inner_radius.txt');
outRad=load('APP_C18_1_outer_radius.txt');


% Calling the function inertia.m to find the inertia given the input
% values.
result=inertia(mass,inRad,outRad);

% Using first loop to display resutls of each vector.
formatSpec='\nMoreover, the sphere with the highest moment of inertia is the one with inner radius %f, outer radius %f, and mass %f. Its moment of inertia is %f.';
FileID=fopen('APP_C18_1_sphere_output.txt','w');

for k=1:5
    fprintf(FileID,'\nThe moment of inertia for the sphere with mass %f,\n inner radius of %f,\n and outer radius of %f is %f.\n',mass(k,:),inRad(k,:),outRad(k,:),result(k,:));
end

% Setting up variables for second loop.
d=0;
record=0;

% Second loop. This loop calculates the highest moment of inertia, and
% assigns it to a "record" variable for later reference.
for k=1:5
    if k>1
        d=k-1;
    else
        d=1;
    end
    
    if result(k,:)>result(d,:)
       record=k;
    end
end

% Using the "record" variable, this print statement shows which sphere had
% the highest moment of inertia.

fprintf(FileID,formatSpec,inRad(record,:),outRad(record,:),mass(record,:),result(record,:));
fclose(FileID);

