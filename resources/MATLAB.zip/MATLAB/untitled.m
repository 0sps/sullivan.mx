clear
clc

x = [1 2 3 4 5 6; 1 2 3 4 ]
y = [3 4 5 6 7 8]
fprintf('\n');

z = x.*y