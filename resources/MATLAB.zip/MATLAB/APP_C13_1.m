fprintf ('\n************************************************') 
fprintf ('\n* Name:     Sean Sullivan       Date: 09/16/19 *') 
fprintf ('\n* Seat: 17  File: APP_C11_1.m                  *') 
fprintf ('\n* Instructor:                      Morin 10:20 *') 
fprintf ('\n************************************************')

% Loading the data from all 3 .dat files
T1=load('APP_C13_1_T1.dat');
T2=load('APP_C13_1_T2.dat');
T3=load('APP_C13_1_T3.dat');

%Creating (if file does not exist) 
% or opening the file (if it exists)
Total=fopen('APP_C13_1_Total.dat','w');

% Printing the values
fprintf(Total,'%i\n',T1);
fprintf(Total,'%i\n',T2);
fprintf(Total,'%i\n',T3);

% I checked this visually by looking at the resulting 
% Total data file and comparing the values to those in 
% the T1 and T2 data files. 