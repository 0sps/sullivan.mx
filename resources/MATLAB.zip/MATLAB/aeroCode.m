clear all
clc

ang = xlsread('Aero.xlsx','Experimental','A10:A13');
lift0018 = xlsread('Aero.xlsx','Experimental','C10:C13');
lift0024 = xlsread('Aero.xlsx','Experimental','G10:G13');
lift4418 = xlsread('Aero.xlsx','Experimental','K10:K13');

bestFit0018 = polyfit(ang, lift0018, 1);
bestFit0024 = polyfit(ang, lift0024, 1);
bestFit4418 = polyfit(ang, lift4418, 1);

y0018 = polyval(bestFit0018,ang);
y0024 = polyval(bestFit0024,ang);
y4418 = polyval(bestFit4418,ang);

plot(ang,lift0018, 'r*');
hold on
plot(ang,lift0024, 'g*');
plot(ang,lift4418, 'b*');

plot(ang,y0018,'r-');
plot(ang,y0024,'g-');
plot(ang,y4418,'b-');
xlabel('Angle of Attack (Degrees)');
ylabel('Coefficient of Lift');
title('Angle of Attack vs. Coefficient of Lift');
legend('NACA 0018','NACA 0024','NACA 4418');
hold off






