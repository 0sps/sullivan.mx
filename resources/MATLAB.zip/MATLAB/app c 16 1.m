fprintf ('\n************************************************') 
fprintf ('\n* Name:     Sean Sullivan       Date: 09/26/19 *') 
fprintf ('\n* Seat: 17  File: APP_C16_1.m                  *') 
fprintf ('\n* Instructor:                      Morin 10:20 *') 
fprintf ('\n************************************************')

% Loading the data
data=load('APP_C16_1_BacteriaCount.txt');

% Importing the data from the data variable into a second variable
% containing ONLY the results
results=data(:,2);

% Zeroing variables
low=0;
mediumlow=0;
medium=0;
mediumhigh=0;
high=0;

% For loop, iqf statement
for count=1:1:100
    
    if results(count) < 2.5
        low=low+1;

    elseif results(count) < 4.5
        mediumlow=mediumlow+1;

    elseif results(count) < 6.5
         medium=medium+1;

    elseif results(count) < 8.5
         mediumhigh=mediumhigh+1;

    elseif results(count) >= 8.5
         high=high+1;
    end
end

% Printing the reuslts of the analysis.
fprintf('\nAfter analysis, the results of the experiment are as follows:');
fprintf('\nThere were %i Low values,',low);
fprintf('\nThere were %i Medium-low values,',mediumlow);
fprintf('\nThere were %i Medium values,',medium);
fprintf('\nThere were %i Medium-high values,',mediumhigh);
fprintf('\nAnd there were %i High values.',high);
