clear
clc
fprintf ('\n************************************************') 
fprintf ('\n* Name:     Sean Sullivan       Date: 10/07/19 *') 
fprintf ('\n* Seat: 17  File: APP_C_19_1                   *') 
fprintf ('\n* Instructor:                      Morin 10:20 *') 
fprintf ('\n************************************************')

% Loading the text file
solar=load('APP_C19_1_solar.txt');

% Storing the text file in two variables
barcode=solar(:,1);
power=solar(:,2);

% Setting up a loop to find max value
pw1=0;
pwprev=0;

for k=1:1:120
    pw1=power(k,1);
    if pwprev < pw1
        pwprev=pw1;
    end
end

fprintf('\nThe maximum power output (according to the loop) is %f.',pwprev);

% Finding max value using MAX command
pwmax=max(power);
fprintf('\nThe maximum power output (according to the MAX command) is %f',pwmax);

% Setting up a loop to find min value
pw1=0;
pwprev=1000000;

for k=1:1:120
    pw1=power(k,1);
    if pwprev > pw1
        pwprev=pw1;
    end
end

fprintf('\nThe minimum power output (according to the loop) is %f.',pwprev);

% Finding max value using MIN command
pwmin=min(power);
fprintf('\nThe minimum power output (according to the MIN command) is %f',pwmin);

% Finding the average value without using mean
total=sum(power);
len=length(power);
av=total/len;
fprintf('\nThe average power value (without using the mean function) is %f',av);

av = 0;

% Finding the average value using mean
av=mean(power);
fprintf('\nThe average power value (using the mean function) is %f',av);

% Finding the standard deviation without using std()
for k=1:1:120
    val=power(k);
    v=val-av;
    num(k)=v^2;
end
presq=sum(num);
presq=presq/119;
sqq=sqrt(presq);
fprintf('\nThe standard deviation (without using std) is %f',sqq);


% Finding the standard deviation using std
newsq=std(power);
fprintf('\nThe standard deviation (using std) is %f',newsq);

% Finding out which panels fall outside of required values

lowest=49;
highest=51;

for k=1:1:120
    if power(k)< 49 || power(k) > 51
        bc=barcode(k);
fprintf('\nSolar panel with barcode %i fell outside the acceptable range of 49 to 51 Watts.',bc);
    end
end

% Testing the SD to ensure it falls within the acceptable range.
newmax=av+newsq;
newmin=av-newsq;

fprintf('\n\nThe calculated standard deviation of %f will lead to a maximum value of %f and a minimum value of %f, well within the acceptable values.',newsq,newmax,newmin);












