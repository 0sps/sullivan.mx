% Creating a function to multiply a vector of input values and multiply
% them by the conversion ratios of energy per mol of gas.
function te = combust(i)
    p = [803 1437 2044 2650];
   for z=1:1:4
       te(z) = p(z)*i(z);
   end
   
end


