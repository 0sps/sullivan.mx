fprintf ('\n************************************************')
fprintf ('\n*   Name: Sean Sullivan Date:   09/16/19       *')
fprintf ('\n*   Seat: 17    File: APP_C11_1.m              *')
fprintf ('\n*   Instructor: Morin 10:20                    *')
fprintf ('\n************************************************')

% Assumptions: A month is 30 days, and a year is 365 days.

%Getting input from user
yearsAgo=input('\nHow many complete years ago did the experiment begin? ');
monthsAgo=input('\nHow many complete months ago did the experiment begin? ');
daysAgo=input('\nHow many complete days ago did the experiment begin? ');
hoursAgo=input('\nHow many complete hours ago did the experiment begin? ');
minutesAgo=input('\nHow many minutes ago did the experiment begin? ');
secondsAgo=input('\nHow many seconds ago did the experiment begin? ');

%Combining all results into one fprintf function.
fprintf('\nThe experiment began %i years, %i months, %i days, %i hours, %i minutes, and %i seconds ago.',yearsAgo,monthsAgo,daysAgo,hoursAgo,minutesAgo,secondsAgo);

%Calculating and printing number of seconds
secondsperday = 60*60*24;

secondsYear = yearsAgo*365*secondsperday;
secondsMonths = monthsAgo * 30 * secondsperday;
secondsDays = daysAgo * secondsperday;
secondsMinutes = minutesAgo * 60;
secondsSeconds = secondsAgo;

totalSeconds = secondsYear+secondsMonths+secondsDays+secondsHours+secondsMinutes+secondsSeconds;

fprintf('\nThis is equivalent to %i seconds. The experiment began %i seconds ago.',totalSeconds,totalSeconds);

%Calculating and printing hours
totalHours = ((totalSeconds/60)/60);
fprintf('\nThis is equivalent to %.2f hours. The experiment began %.2f hours ago.',totalHours,totalHours);
