function inert=inertia(x,y,z)
    mas=x.*2;
    mass=mas./5;
    
    inrad3=y.^3;
    outrad3=z.^3;
    inrad5=y.^5;
    outrad5=z.^5;
    
    pt1=outrad5-inrad5;
    pt2=outrad3-inrad3;
    pt=pt1./pt2;
    inert=pt.*mass;
    
end
