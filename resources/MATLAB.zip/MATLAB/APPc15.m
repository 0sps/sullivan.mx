fprintf ('\n************************************************') 
fprintf ('\n* Name:     Sean Sullivan       Date: 09/16/19 *') 
fprintf ('\n* Seat: 17  File: APP_C15_1.m                  *') 
fprintf ('\n* Instructor:                      Morin 10:20 *') 
fprintf ('\n************************************************')

% Loading the data files
t1=load('APP_C15_1_T1.dat');
t2=load('APP_C15_1_T2.dat');
t3=load('APP_C15_1_T3.dat');

% Setting all variables to zero
Time1=0;
Time2=0;
Time3=0;

% Setting up for loops to define vectors
for x=1:1:50
    Time1(x)=x;
end

Time2=0;
for x=51:1:100
    Time2(x-50)=x;
end

Time3=0;
for x=101:1:150
    Time3(x-100)=x;
end

% Setting a final time vector
for x=1:50
    t4(x)=(x);
    p4 = (0.005 * t4.^3);
end

% Plotting all the data values
plot(Time1,t1,'-ro');
hold on;
plot(Time2,t2,'-gx');
plot(Time3,t3,'-k');
plot(t4,p4,'-');
hold off;

% Completing the titel and labels with units & legend
xlabel('Time (seconds)');
ylabel('Temperature (Kelvin)');
title('Temperature change through 150 seconds');
legend('1-50 Seconds','51-100 Seconds','101-150 Seconds','Theoretical Eqation for Seconds');

