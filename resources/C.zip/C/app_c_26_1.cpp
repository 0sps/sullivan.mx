/***************************************************/ 
/*  Name:  Sean Sullivan   Date:  10/18/19         */ 
/*  Seat:  00    File:  APP_C26_1.cpp              */ 
/*  Instructor:  Morin 10:20                       */
/***************************************************/ 

/* Initializing program by including libraries */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

int main (void)
{
	
//Declaring variables
int win, loss, years, current, k, countH, countL, hiyear, loyear;
float winP[16], lossP[16], total[16], wins[16], losses[16];
FILE *outpt;
outpt=fopen("APP_C26_1_result.txt","w");

//First print statement
printf ("\n************************************************"); 
printf ("\n* Name:     Sean Sullivan       Date: 10/22/19 *"); 
printf ("\n* Seat: 00  File: APP_C26_1.cpp                *"); 
printf ("\n* Instructor:                      Morin 10:20 *"); 
printf ("\n************************************************");


printf("\n\n Please enter the wins and losses of the NBA team from years 2001 to 2016. This system will guide you.\n");

years=2000;

for (k=1; k < 17; k++)
{
	current=years+k;
	printf("\nEnter the wins for year %i: ",current);
scanf("%f",&wins[k]);
}

//Resetting variabes to zero
k=0;
current=0;


//Starting next for loop
for (k=1; k < 17; k++)
{
	current=years+k;
	printf("\nEnter the losses for year %i: ",current);
scanf("%f",&losses[k]);
}

//Doing some variable setting and math; getting total number of games per year
k=0;

//Starting the next for loop for wins and losses
for (k=1; k<17; k++)
{
	total[k] = wins[k] + losses[k];
}

for (k=1; k<17; k++)
{
	winP[k] = (wins[k] / total[k]) * 100;
	lossP[k] = (losses[k] / total[k]) * 100;
}

countH=1;
countL=1;
current=2000;
for (k=1; k<17; k++)
{
	if (winP[k] >= winP[countH])
	{
		countH=k;
	}
	
	else if (winP[k] <= winP[countL])
	{
		countL=k;
	}
		
	}
	hiyear=current+countH;
	loyear=current+countL;
	
	
	printf("\n\nThe highest winning percentage was year %i with %f percent wins.",hiyear,winP[countH]);
	printf("\nThe lowest winning percentage was year %i with %f percent wins.",loyear,lossP[countL]);
	fprintf(outpt,"\n\nThe highest winning percentage was year %i with %f percent wins.",hiyear,winP[countH]);
	fprintf(outpt,"\nThe lowest winning percentage was year %i with %f percent wins.",loyear,lossP[countL]);

	fclose(outpt);
	
}

