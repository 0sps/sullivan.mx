 /***************************************/
/* Name: Sean Sullivan Date: 10/31/19  */
/* Code: APP EWA7                      */
/***************************************/
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <iostream>

int main()
{

// Declaring and defining as many variables as possible
int siz = 0;
int status = 0;
int one, two, three, four, onee, twoo, threee, fourr;

float oneTot, twoTot, threeTot, fourTot, oneeTot, twooTot, threeeTot, fourrTot;
float oneavg, twoavg, threeavg, fouravg;
float oneeavg, twooavg, threeeavg, fourravg;

oneavg = twoavg = threeavg = fouravg = oneeavg = twooavg = threeeavg = fourravg = one = two = three = four = onee = twoo = threee = fourr = oneTot = twoTot = threeTot = fourTot = oneeTot = twooTot = threeTot = fourrTot = 0;

printf("***************************************\n");
printf("* Name: Sean Sullivan Date:10/31/19   *\n");
printf("* Code: APP EWA7                      *\n");
printf("***************************************\n");

//Declaring input and output file pointers
FILE *inpt, *outpt;

//Opening input and output files
inpt=fopen("EWA_07_random.dat","r");
outpt = fopen("EWA_07.txt","w");

//Using a for loop to determine the number of lines in the data file 
char c;
for (c=getc(inpt); c != EOF; c=getc(inpt))
	{
	if (c == '\n')
		{
		siz++;
		}
	}

//Moving back to the beginning of the file to read data in to variables
fseek(inpt,0,SEEK_SET);

//Declaring the integer and float arrays 
int intpool[siz];
float floatpool[siz];

/* This for loop first reads the data into 2 variables, one for the ints and one for the floats */
for (int k = 0; k < siz; k++)
	{
	status = fscanf(inpt,"%i%f",&intpool[k],&floatpool[k]);	
	}
/* This for loop evaluates the value of each integer and assigns it to the proper variable if it falls within a certain range. It also adds that value to a sum variable, and increments a counter for that range.  */
for (int k = 0; k < siz; k++)
	{
	if (intpool[k] >= 1 && intpool[k] <= 3)
		{
		one++;
		oneTot += intpool[k];
		}
	else if (intpool[k] >= 4 && intpool[k] <= 6)
		{
		two++;
		twoTot += intpool[k];
		}
	else if (intpool[k] >= 7 && intpool[k] <= 9)
		{
		three++;
		threeTot += intpool[k];
		}
	else if (intpool[k] >= 10 && intpool[k] <= 12)
		{
		four++;
		fourTot += intpool[k];
		}
	}

//Setting variables equal to zero in case they somehow have values in memory
twoo = 0;
threee = 0;
threeeTot = 0;
onee = 0;
fourr = 0;

/* This for loop checks each float and finds which range it falls within, adds that value to a sum variable, and increments a counter for that range */
for (int k = 0; k < siz; k++)
	{
	if (floatpool[k] >= 0 && floatpool[k] <= 25)
		{
		onee++;
		oneeTot += floatpool[k];
		}
	else if (floatpool[k] > 25 && floatpool[k] <= 50)
		{
		twoo++;
		twooTot += floatpool[k];
		}
	else if (floatpool[k] > 50 && floatpool[k] <= 75)
		{
		threee++;
		threeeTot += floatpool[k];
		}
	else if (floatpool[k] > 75 && floatpool[k] <= 100)
		{
		fourr++;
		fourrTot += floatpool[k];
		}
}

//Printing the values of the counters to the screen and to the output file
printf("\nThere are: \n%i integers falling within 1 and 3,\n%i integers falling within 4 and 6,\n%i integers falling within 7 and 9,\nand %i integers falling within 10 and 12.",one,two,three,four);	
printf("\n\nThere are: \n%i floats between 0 and 25 (inclusive),\n%i floats falling within 25 and 50 (inclusive),\n%i floats falling within 50 and 75 (inclusive),\nand %i floats falling within 75 and 100 (inclusive).",onee,twoo,threee,fourr);					
fprintf(outpt,"THIS IS THE OUTPUT FILE.\nThere are: \n%i integers falling within 1 and 3,\n%i integers falling within 4 and 6,\n%i integers falling within 7 and 9,\nand %i integers falling within 10 and 12.",one,two,three,four);	
fprintf(outpt,"\n\nThere are: \n%i floats between 0 and 25 (inclusive),\n%i floats falling within 25 and 50 (inclusive),\n%i floats falling within 50 and 75 (inclusive),\nand %i floats falling within 75 and 100 (inclusive).",onee,twoo,threee,fourr);	
//Finding the average of all the ranges
oneavg = oneTot / one;
twoavg = twoTot / two;
threeavg = threeTot / three;
fouravg = fourTot / four;

oneeavg = oneeTot / onee;
twooavg = twooTot / twoo;
threeeavg = threeeTot / threee;
fourravg = fourrTot / fourr;

//Printing to the screen
printf("\n\nThe averages of each range are below:\n\nIntegers");
printf("\n1 to 3: %f\n4 to 6: %f\n7 to 9: %f\n10 to 12: %f",oneavg,twoavg,threeavg,fouravg);
printf("\n\nFloats\n0 to <=25: %f\n>25 to <=50: %f\n>50 to <=75: %f\n>75 to <= 100: %f",oneeavg,twooavg,threeeavg,fourravg);
//Printing to the file
fprintf(outpt,"\n\nThe averages of each range are below:\n\nIntegers");
fprintf(outpt,"\n1 to 3: %f\n4 to 6: %f\n7 to 9: %f\n10 to 12: %f",oneavg,twoavg,threeavg,fouravg);
fprintf(outpt,"\n\nFloats\n0 to <=25: %f\n>25 to <=50: %f\n>50 to <=75: %f\n>75 to <= 100: %f",oneeavg,twooavg,threeeavg,fourravg);
	
fclose(inpt);
fclose(outpt);
	
		}
		