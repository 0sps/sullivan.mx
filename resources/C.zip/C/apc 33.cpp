#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <string.h>
#include <unistd.h>
//rectus femoris is pennate
//vastus intermedius is parallel

struct Parallel 
{   
	//Input variables  
	char name[30];    
	float w,f,l,a;    
	//Result variables    
	float force; 
} aParallel, *aParrPtr;
 
struct Pennate 
{    
	//Input variables    
	char name[30];    
	float w,f,l,alpha;    
	//Result variables    
	float force, C_ratio; 
} aPennate, *aPennPtr; 
		
		void setvals(struct Parallel *, struct Pennate *); 
		void calculate(struct Parallel *, struct Pennate *); 
		void present(struct Parallel, struct Pennate); 

//Starting the program
int main()
{
	printf ("\n************************************************");
	printf ("\n* Name:     Sean Sullivan       Date: 11/12/19 *");
	printf ("\n* Seat: 17  File: APP_C33.cpp                  *");
	printf ("\n* Instructor:                      Morin 10:20 *");
	printf ("\n************************************************\n\n");

//Defining variables for each struct
struct Pennate aPennate;
struct Parallel aParallel;

//Calling each function
setvals(&aParallel,&aPennate); 
calculate(&aParallel,&aPennate); 
present(aParallel,aPennate); 

}

//First function definition. 
	void setvals (struct Parallel *, struct Pennate *)
{
	//Getting the names of the muscles
printf("\nEnter pennate muscle name:\n");
fgets(aPennate.name,30,stdin);
printf("\nEnter parallel muscle name:\n");
fgets(aParallel.name,30,stdin);
//Getting the values for each muscle type
printf("\n\nPlease enter the following values for the %s muscle:\n",aPennate.name);
printf("\tw: ");
scanf("%f",&aPennate.w);
printf("\n\ta: ");
scanf("%f",&aPennate.alpha);
printf("\n\tf: ");
scanf("%f",&aPennate.f);
printf("\n\tl: ");
scanf("%f",&aPennate.l);
printf("\n\nPlease enter the following values for the %s muscle:\n",aParallel.name);
printf("\tw: ");
scanf("%f",&aParallel.w);
printf("\n\ta: ");
scanf("%f",&aParallel.a);
printf("\n\tf: ");
scanf("%f",&aParallel.f);
printf("\n\tl: ");
scanf("%f",&aParallel.l);
};

//Function 2.
void calculate(struct Parallel *, struct Pennate *)
{
//Calculating parallel and pennate muscle forces. Also calculating a C ratio.
aParallel.force = aParallel.w * 2 * aParallel.a * aParallel.f;
aPennate.force = aPennate.w * 2 * aPennate.f * aPennate.l * sin(aPennate.alpha) * cos(aPennate.alpha);
aPennate.C_ratio = sin(aPennate.alpha);

};

//Printing the results
void present(struct Parallel, struct Pennate)
{
printf("\n\n \t\t---Results---");
printf("\nThe C-ratio is %f",aPennate.C_ratio);
printf("\nThe force of the parallel muscle, %s, is %f",aParallel.name,aParallel.force);
printf("\nThe force of the pennate muscle, the %s, is %f",aPennate.name,aPennate.force);


}
