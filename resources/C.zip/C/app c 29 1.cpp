/***************************************/
/* Name: Sean Sullivan Date: 10/29/19  */
/* Code: APP C29-1                     */
/***************************************/
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <unistd.h>


int main()
{
	printf("***************************************\n");
	printf("* Name: Sean Sullivan Date:10/29/19   *\n");
	printf("* Code: APP C29-1                     *\n");
	printf("***************************************\n");
/*
	Declare variables for input and output file pointers, angular speed
	torque, time, and sum, average, max, index tracking.

	Initialize as needed.
*/
FILE *inpt, *outpt;
float avgSpeed, timee, sum, avg, max, min, avgTorque, maxCurrent, timeBetween;
int indx, status, maxIndex, minIndex, timeMax, timeMin, size, torqueMaxindex;
int check = 0;
float speed[12000], torque[12000], armC[12000], maxTorque, torqueTotal;
int count_lines = 0;

/* 
	Open input file for reading
*/
	
inpt = fopen("APP_C29_1_motor.dat","r");
/* 
	Check to see if the file opened
	Tell user the file did not open and don't do anything else
	*/
if (inpt == NULL)
	{
	printf("\n\nFile failed to open !");
	return 1;
	}
/*
	Else, tell the user the file opened successfuly and proceed with
	processing the file.
*/
	else
	{
	printf("\n\nInput file opened successfully.");
	}
/*
	Use while loop to read the file until the end and store all the
	speed data.  Read in data ignoring columns 1, 2, and 4.  Store
	data from column 3 in an array.  Count the number of data points.
*/
count_lines = 0;
while (check != EOF)
	{
	check = fscanf(inpt,"%*s%*s%f%*f",&speed[count_lines]);
	if (check != EOF)
		{
		count_lines++;
		}	
	}
	
/* 
	Close the input file, but only if you opened it successfully.
*/
fclose(inpt);
/*
	Use for loop to go through angular speed data and determine the max and min.  Store
	max, max index, min, min index.
*/


maxIndex = 0;
minIndex = 0;
for (int k = 0; k < count_lines; k++)
	{
	if (speed[k] <= speed[minIndex])
		{
		min = speed[k];
		minIndex = k;
		}
	if (speed[k] >= speed[maxIndex])
		{
		max = speed[k];
		maxIndex = k;
		}
	}
	
/* 
	Calculate the elapsed time between the max and min speeds using
	the indices.  Use fabs() to ensure time result is positive.
*/

/*Here I define floats for the max and min time values, then set them to be eqiuvalent to the maximum and minimum time values found in the previous loop. */
float timeMi = 0;
float timeMa = 0;
timeMi = minIndex * 0.1;
timeMa = maxIndex * 0.1;
timeBetween = fabs(timeMi - timeMa);


/* 
	Compute the torque array from the speed array with the DC motorspeed equation 
*/

for (int k=0; k < count_lines; k++)
	{
	armC[k] = (50 - speed[k]) / 2;
	torque[k] = 4 * armC[k];
	}

/* 
	Use for loop to go through torque data and determine the max and
	total so that you can use total to calculate average.
*/

torqueMaxindex = 0;
torqueTotal = 0;
for (int k=0; k < count_lines; k++)
	{
	if (torque[k] > torque[torqueMaxindex])
		{
		torqueMaxindex = k;
		maxTorque = torque[k];
		}
	else if (torque[k] < torque[torqueMaxindex])
		{
		maxTorque = torque[torqueMaxindex];
		}
		
	torqueTotal = torqueTotal + torque[k];
	}


/* 
	Calculate the average of the torque values
*/
	avgTorque = torqueTotal / count_lines;
	
/* 
	Calculate the max current which occurs at the max torque 
*/

int MaxArmCurrent = 0;
for (int k=0; k < count_lines; k++)
	{
	if (armC[k] > armC[MaxArmCurrent])
		{
		MaxArmCurrent = k;
		maxCurrent = armC[k];
		}
	}

/* 
	Print results to screen
*/

printf("\n\nThe maximum current is %f.\nThe average torque is %f.\nThe maximum torque is %f.\nThe maximum and minimum speed values are %f and %f, respectively.\nThe elapsed time between the maximum and minimum speed values is %f seconds.",maxCurrent,avgTorque,maxTorque,max,min,timeBetween);

/* 
	Open output file for writing 
*/
outpt = fopen("APP_C29_1_result.txt","w");
/* 
	Check to see if the output file opened
*/
if (outpt == NULL)
	{
	printf("\n\nFile failed to open !");
	return 1;
	}
/*
	Else, tell the user the file opened successfuly and proceed with
	processing the file.
*/
	else
	{
	printf("\n\nOutput file opened successfully.");
	}

/* 
	Print results to output file 
*/
fprintf(outpt,"\n\nThe maximum current is %f.\nThe average torque is %f.\nThe maximum torque is %f.\nThe maximum and minimum speed values are %f and %f, respectively.\nThe elapsed time between the maximum and minimum speed values is %f seconds.\nNote:These values were checked via calculations in Excel, and verified to be valid.",maxCurrent,avgTorque,maxTorque,max,min,timeBetween);
/* 
	Close output file, but only if you opened it successfully.
*/



/* 
NOTE:
	These values were checked via calculations in Excel, and verified to be valid. 

*/

}