# include <stdio.h>
# include <math.h>
# define v 1.3333333
# define pi 3.14159265

int main (void)
{
	printf ("\n************************************************");
	printf ("\n* Name:     Sean Sullivan       Date: 10/27/19 *");
	printf ("\n* Seat: 17  File: EWA06.m                      *");
	printf ("\n* Instructor:                      Morin 10:20 *");
	printf ("\n************************************************\n\n");

//Declaring & defining files and pointers
FILE *inpt, *outpt;
inpt = fopen("EWA_06_gumdrops.dat","r");
outpt = fopen("EWA_06.txt","w");

//Declaring & defining variables	
float dia[15], rad[15], volume[15], surfaceArea[15];
float vol, average, averageR, averageV, averageSA, avgRad, avgVol, avgSA, total;
int status, lessThan, greaterThan;


//Reading into variables
for (int x=1; x<16; x++)
	{
	status = fscanf(inpt,"%f", &dia[x]);
	rad[x] = dia[x] * 0.5;
	}
	
//Calculating values
for (int x=1; x<16; x++)
	{
	volume[x] = (v * pi * pow(rad[x], 3));
	surfaceArea[x] = (4 * pi * pow(rad[x], 2));
	}

// Setting up a for loop to calculate all averages
avgRad = 0;
avgVol = 0;
avgSA = 0;
for (int x=1; x<16; x++)
	{ 
	avgRad = avgRad + rad[x];
	avgVol = avgVol + volume[x];
	avgSA = avgSA + surfaceArea[x];
	}
//Finally calculating the averages
averageR = avgRad / 15;
averageV = avgVol / 15;
averageSA = avgSA / 15;

//Printing values of each sphere
printf("\n		Sphere data\n\n");
printf("Radius(cm)		Volume(cm^3)	Surface Area(cm^2)");
for (int x=1; x<16; x++)
	{
	printf("\n%f		%f		%f.",rad[x], volume[x], surfaceArea[x]);
	}

//Printing the averages
printf("\n\nThe average radius for all spheres is %f. The average volume is %f. The average surface area is %f.\n", averageR, averageV, averageSA);
	
	
/*Finding which values fall out of the averages by setting 2 counter variables to zero and then checking each value, then incrementing one of the counters.*/
lessThan = greaterThan = 0;
for (int x=1; x<16; x++)
	{
	if (rad[x] <= averageR)
		{
		lessThan++;
		}
	else if (rad[x] > averageR)
		{
		greaterThan++;
		}
	}

//Printing to user screen
printf("%d sphere radii fall at or below the average, while %d are above it.", lessThan, greaterThan);

//Printing to file
		fprintf(outpt,"\n		Sphere data\n\n");
		fprintf(outpt,"Radius(cm)		Volume(cm^3)	Surface Area(cm^2)");
		for (int x=1; x<16; x++)
			{
			fprintf(outpt,"\n%f		%f		%f.",rad[x], volume[x], surfaceArea[x]);
			}
fprintf(outpt,"\n\n%d sphere radii fall at or below the average, while %d are above it.", lessThan, greaterThan);
fprintf(outpt,"\n\nThe average radius for all spheres is %f. The average volume is %f. The average surface area is %f.\n", averageR, averageV, averageSA);		
	
	
}
