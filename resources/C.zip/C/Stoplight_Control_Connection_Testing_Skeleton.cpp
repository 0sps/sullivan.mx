#include <FEHLCD.h>
#include <FEHIO.h>
#include <FEHUtility.h>
// Import all necessary libraries here


//Sean sullivan, Brendan Chong


#define SLEEP 1.0
// Fill in the pin declarations
DigitalOutputPin green1(FEHIO::P0_0);
DigitalOutputPin yellow1(FEHIO::P0_1);
DigitalOutputPin red1(FEHIO::P0_2);
DigitalOutputPin walk1(FEHIO::P0_4);
DigitalOutputPin dontWalk1(FEHIO::P0_3);
DigitalOutputPin green2(FEHIO::P1_0);
DigitalOutputPin yellow2(FEHIO::P1_1);
DigitalOutputPin red2(FEHIO::P1_2);
DigitalOutputPin walk2(FEHIO::P1_4);
DigitalOutputPin dontWalk2(FEHIO::P1_3);
int main(){
    LCD.Clear();
    LCD.WriteLine("Waiting for touch.");
    float x,y;
    while (!LCD.Touch(&x, &y)) {
        // Screen is not being touched
    }
    while (LCD.Touch(&x, &y)) {
        // Screen is being touched
    }
    LCD.WriteLine("Starting!");
    while (true) {
            green1.Write(true);
            yellow1.Write(false);
            red1.Write(false);
            green2.Write(false);
            yellow2.Write(false);
            red2.Write(true);
            dontWalk1.Write(false);
            walk1.Write(true);
            dontWalk2.Write(true);
            walk2.Write(false);
Sleep(5.0);

        dontWalk1.Write(true);
        dontWalk2.Write(true);
        walk1.Write(false);
        walk2.Write(false);
    Sleep(0.25);
        dontWalk1.Write(false);
        dontWalk2.Write(true); 
    Sleep(0.25);
        dontWalk1.Write(true);
        dontWalk2.Write(true);
    Sleep(0.25);
        dontWalk1.Write(false);
        dontWalk2.Write(true);         
    Sleep(0.25);
        dontWalk1.Write(true);
        dontWalk2.Write(true);
    Sleep(0.25);
        dontWalk1.Write(false);
        dontWalk2.Write(true);         
    Sleep(0.25);
        dontWalk1.Write(true);
        dontWalk2.Write(true);
    Sleep(0.25);
        dontWalk1.Write(false);
        dontWalk2.Write(true);         
    Sleep(0.25);

               green1.Write(false);
               yellow1.Write(true);
               red1.Write(false);
               green2.Write(false);
               yellow2.Write(false);
               red2.Write(true);
               dontWalk1.Write(true);
               walk1.Write(false);
               dontWalk2.Write(true);
               walk2.Write(false);
Sleep(2.0);

           green1.Write(false);
           yellow1.Write(false);
           red1.Write(true);
           green2.Write(false);
           yellow2.Write(false);
           red2.Write(true);
           dontWalk1.Write(true);
           walk1.Write(false);
           dontWalk2.Write(true);
           walk2.Write(false);
        
        Sleep(1.0);
           green1.Write(false);
           yellow1.Write(false);
           red1.Write(true);
           green2.Write(true);
           yellow2.Write(false);
           red2.Write(false);
           dontWalk1.Write(true);
           walk1.Write(false);
           dontWalk2.Write(false);
           walk2.Write(true);
    Sleep(5.0);

        dontWalk1.Write(true);
        dontWalk2.Write(true);
        walk1.Write(false);
        walk2.Write(false);
    Sleep(0.25);
        dontWalk1.Write(true);
        dontWalk2.Write(false); 
    Sleep(0.25);
        dontWalk1.Write(true);
        dontWalk2.Write(true);
    Sleep(0.25);
        dontWalk1.Write(true);
        dontWalk2.Write(false);         
    Sleep(0.25);
        dontWalk1.Write(true);
        dontWalk2.Write(true);
    Sleep(0.25);
        dontWalk1.Write(true);
        dontWalk2.Write(false);         
    Sleep(0.25);
        dontWalk1.Write(true);
        dontWalk2.Write(true);
    Sleep(0.25);
        dontWalk1.Write(true);
        dontWalk2.Write(false);         
    Sleep(0.25);
    
           green1.Write(false);
           yellow1.Write(false);
           red1.Write(true);
           green2.Write(false);
           yellow2.Write(true);
           red2.Write(false);
           dontWalk1.Write(true);
           walk1.Write(false);
           dontWalk2.Write(true);
           walk2.Write(false);
 sleep(2.0);


           green1.Write(false);
           yellow1.Write(false);
           red1.Write(true);
           green2.Write(false);
           yellow2.Write(false);
           red2.Write(true);
           dontWalk1.Write(true);
           walk1.Write(false);
           dontWalk2.Write(true);
           walk2.Write(false);
    Sleep(1.0);
    }
    return 0;
}