/***************************************************/ 
/*  Name:  Sean Sullivan   Date:  10/24/19         */ 
/*  Seat:  00    File:  APP_C27_1.cpp              */ 
/*  Instructor:  Morin 10:20                       */
/***************************************************/ 

#include <stdio.h>
#include <math.h>
int main()
{
//Declaring all varibables
float t1me[100],press[100],time[100],averaget,averageb;
int i, status, locamax, locamin, prmax, prmin;

//Opening the input and output files
FILE *inpt;
FILE *outpt;
inpt = fopen("APP_C27_1_bp_hr.dat","r");
outpt = fopen("APP_C27_1_result.txt","w");

//First print statement
printf ("\n************************************************"); 
printf ("\n* Name:     Sean Sullivan       Date: 10/24/19 *"); 
printf ("\n* Seat: 00  File: APP_C27_1.cpp                *"); 
printf ("\n* Instructor:                      Morin 10:20 *"); 
printf ("\n************************************************");

//Setting up first for loop to read into variables
for (i=1;i<=100;i++)
	{
	status=fscanf(inpt,"%f	%f",&t1me[i],&press[i]);
	time[i] = 1 / t1me[i];

	}

//Setting up second for loop to determine average 
for (i=1;i<=100;i++)
	{
	averaget += time[i];
	averageb += press[i];
	}
//The following variables are now the average values
averaget = averaget / 100;
averageb = averageb / 100;

// Defining variables for maximum and minimum time & pressure.
// The following loop determines the maximum values
locamax = locamin = 1;
prmax = prmin  = 1;

for (i=1;i<=100;i++)
	{
	if (time[i] <= time[locamin])
		{
		locamin = i;
		}
	if (time[i] >= time[locamax])
		{
		locamax = i;
		}
	if (press[i] < press[prmin])
		{
		prmin = i;
		}
	if (press[i] > press[prmax])
		{
		prmax = i;
		}
	}

// Printing all the values
printf("\n\nThe highest time value is %f, the lowest is %f, and the average is %f. The highest pressure value is %f, the lowest is %f, and the average is %f. These values have also been printed to APP_C27_1_result.txt.",time[locamax],time[locamin],averaget,press[prmax],press[prmin],averageb);

fprintf(outpt,"\n\nThe highest time value is %f, the lowest is %f, and the average is %f. The highest pressure value is %f, the lowest is %f, and the average is %f. These values have also been printed to APP_C27_1_result.txt.",time[locamax],time[locamin],averaget,press[prmax],press[prmin],averageb);

//Closing the output file
fclose(outpt);

}
