#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <string.h>
#include <unistd.h>
#include <iostream>
#include <fstream>
using namespace std;

char savingsCheck[] = "Savings";
char checkingCheck[] = "Checking";
char newName[] = "Personal";

class Account
{       
	public:
		Account(int b = 0, char c[] = " ", float d = 0, float e = 0);
		Account();
		void transaction(float amt, char acct[]);         
		void inquiry();
		void changename(char newN[]);       
	private:
		long int AccountNum;  
		char Name[30];
		float TotalBalance,Savings,Checking;
};


int main()
{
//Printing
cout << "\n************************************************"; 
cout << "\n* Name:     Sean Sullivan       Date: 11/19/19 *"; 
cout << "\n* Seat: 00  File: APP_C36_1.cpp                *"; 
cout << "\n* Instructor:                      Morin 10:20 *"; 
cout << "\n************************************************\n\n";


Account Bankland1(0);
Account Bankland2(351, "Business", 15000.00, 5600.00);


Bankland2.inquiry();


float deposit1 = 435.00;
float withdrawal1 = -58.35;

Bankland1.changename(newName);
Bankland1.transaction(deposit1, savingsCheck);
Bankland2.transaction(withdrawal1, checkingCheck);

Bankland1.inquiry();
Bankland2.inquiry();
}

void Account::inquiry()
	{
	cout << "\n\n\t---ACCOUNT SUMMARY---" << endl;
	cout << "\t\tAccount Number: " << AccountNum << endl;
	cout << "\t\tAccount name: " << Name << endl;
	cout << "\t\tSavings Balance: $" << Savings << endl;
	cout << "\t\tChecking Balance:  $" << Checking;
	cout << flush;
	sleep(1);
	};

	
Account::Account(int b, char c[], float d, float e)
	{
	AccountNum = b;
	strcpy(Name, c);
	Savings = d;
	Checking = e;
	TotalBalance = e + d;
	};

void Account::transaction(float amt, char acct[])        
	{
	cout << "\nConducting a transaction of $" << amt  << " into account " << acct << "...\n";
	cout << flush;
	if (strcmp(savingsCheck, acct) == 0)
		{
		Savings += amt;
		}
	if (strcmp(checkingCheck, acct) == 0)
		{
		Checking += amt;
		}
	sleep(2);
	};

void Account::changename(char newN[])     
	{
	cout << "\n\nName of bank account #" << AccountNum << " changed to " << newN << "." << endl;
	cout << flush;
	strcpy(Name,newN);
	sleep(2);
	};


/*

NOTE: These values were verified to be accurate by checking the deposits and withdrawals by hand.

*/
