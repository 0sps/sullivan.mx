#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <string.h>
#include <unistd.h>
#include <iostream>
#include <fstream>
using namespace std;

ifstream inpt("APP_C37_1_anemometry.txt");


//Defining the class "Grid
class Grid
	{
	public:
		//Making the constructor, defining all public functions
		Grid(int y);
		void GetData(int a);
		void FindMax(int a);
		void Average(int a);
		void DisplayValues(int a);
		
		//Defining all private variables
	private:
		int active_probe, max_index; float probe_avg, probe_data[7];	
	};

//The 'start' of the program, int main
int main()
	{
		//Opening print statements
		cout << "\n************************************************"; 
		cout << "\n* Name:     Sean Sullivan       Date: 11/21/19 *"; 
		cout << "\n* Seat: 00  File: APP_C37_1.cpp                *"; 
		cout << "\n* Instructor:                      Morin 10:20 *"; 
		cout << "\n************************************************\n\n";
		
		//Opening the data file, storing it in file pointer inpt
		int a;
		cout << endl << "Enter any probe from 1-5: ";
		cin >> a;    
		Grid g1(a);
		//Calling all the class functions
		g1.GetData(a);
		g1.FindMax(a);
		g1.Average(a);
		g1.DisplayValues(a);
		//Closing the data file
		inpt.close();
	}


//Function definitions below.
//This function initializes the Grid(y) class to have values of 0. 
//The active probe is set to have the input value, y.
Grid::Grid(int y)
	{
	max_index = probe_avg = 0;
	probe_data[0] = 0;
	probe_data[1] = 0;
	probe_data[2] = 0;
	probe_data[3] = 0;
	probe_data[4] = 0;
	probe_data[5] = 0;
	probe_data[6] = 0;
	active_probe = y;
	};
	
//This function inputs the data from the data file.
void Grid::GetData(int a)
{
	float var;
	for (int i=0; i<7; i++)
		{
		inpt >> var;
		probe_data[i] = var;
		}
};

/* This function gets the max index from probe_data array and stores it in max_index. */
void Grid::FindMax(int a)
{
	max_index = 0;
	for (int i=0; i<7; i++)
		{
		if (probe_data[max_index] < probe_data[i])
		max_index=i;
		}
};

/* This function finds the average value of the probe_data array and stores it in probe_avg */
void Grid::Average(int a)
{
	float probeTotal = 0;
	
	for (int i=0; i<7; i++)
	probeTotal += probe_data[i];
	probe_avg = probeTotal / 7;
};

//This function displays all the calculated values.
void Grid::DisplayValues(int a)
{
	
	cout << "\n\nFor probe " << a << ", the average velocity across positions 1 - 7 was " << probe_avg << " ft/s." << endl; 
	cout << "The maximum velocity was " << probe_data[max_index] << " ft/s at position 5." << endl;
	
};