#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <string.h>
#include <unistd.h>

#define pi 3.141592654

struct sphere
	{
	float radius; 
	float surface_area;
	float volume;
	char name[50]; 
	};
struct sphere sphereVal;

struct cube
	{
	float side; 
	float face_area; 
	float surface_area; 
	float volume; 
	char name[50]; 
	};
struct cube cubeVal;

struct regtet
	{
	float side; 
	float face_area; 
	float surface_area; 
	float volume; 
	char name[50]; 
	};
struct regtet regtetVal;

char response[2];

void SetSphere (struct sphere *);  
void CalcSphere (struct sphere *);  
void DispSphere (struct sphere *);  
void SetCube (struct cube *);  
void CalcCube (struct cube *);  
void DispCube (struct cube *);  
void SetRegtet (struct regtet *);  
void CalcRegtet (struct regtet *);  
void DispRegtet (struct regtet *);

int main()
{

printf ("\n************************************************"); 
printf ("\n* Name:     Sean Sullivan       Date: 11/14/19 *"); 
printf ("\n* Seat: 00  File: EWA_09.cpp                   *"); 
printf ("\n* Instructor:                      Morin 10:20 *"); 
printf ("\n************************************************\n\n");

/*This is going to be one of my ONLY uses of this command. It is to start the for loop and get user input. */

statement:
	
printf("\n\nWhat would you like to do?\n\ta, A -- Set sphere radius and name \n\tb, B -- Calculate sphere surface area and volume \n\tc, C -- Display sphere radius, surface area, volume, and name  \n\td, D -- Set cube side length and name \n\te, E -- Calculate cube face area, surface area, and volume \n\tf, F -- Display cube side length, face area, surface area, volume, and name  \n\tg, G -- Set regular tetrahedron side length and name\n\th, H -- Calculate tetrahedron face area, surface area, and volume \n\ti, I -- Display tetrahedron side length, face area, surface area, volume, and name  \n\tq, Q -- Quit \n\n\t\t");

scanf("%s",response);
if ((strcmp(response, "A") == 0) || (strcmp(response, "a") == 0))
	{
	SetSphere(&sphereVal);  
	sleep(1);
	goto statement;
	}
if ((strcmp(response, "B") == 0) || (strcmp(response, "b") == 0))
	{
	CalcSphere(&sphereVal);
	sleep(1);
	goto statement;
	}
if ((strcmp(response, "C") == 0) || (strcmp(response, "c") == 0))
	{
	DispSphere(&sphereVal);
	sleep(2);
	goto statement;
	}
if ((strcmp(response, "D") == 0) || (strcmp(response, "d") == 0))
	{
	SetCube(&cubeVal);
	sleep(2);		
	goto statement;
	}
if ((strcmp(response, "E") == 0) || (strcmp(response, "e") == 0))
	{
	CalcCube(&cubeVal);
	sleep(2);
	goto statement;	
	}
if ((strcmp(response, "F") == 0) || (strcmp(response, "f") == 0))
	{
	DispCube(&cubeVal);
	sleep(2);
	goto statement;	
	}
if ((strcmp(response, "G") == 0) || (strcmp(response, "g") == 0))
	{
	SetRegtet(&regtetVal); 
	sleep(2);
	goto statement;	
	}
if ((strcmp(response, "H") == 0) || (strcmp(response, "h") == 0))
	{
	CalcRegtet(&regtetVal);
	sleep(2);
	goto statement;		
	}
if ((strcmp(response, "I") == 0) || (strcmp(response, "i") == 0))
	{
	DispRegtet(&regtetVal);
	sleep(2);
	goto statement;		
	}
if ((strcmp(response, "Q") == 0) || (strcmp(response, "q") == 0))
	{
	sleep(2);
	return 1;
	}
	
	
	
}

void SetSphere(struct sphere *sphereVal)
	{
	printf("\n\nSetting Sphere radius and name...\n");
	printf("\tPlease enter radius: ");
	scanf("%f",&sphereVal->radius);
	printf("\tPlease enter name: ");
	scanf("%s",sphereVal->name);		
	};
void CalcSphere(struct sphere *sphereVal)
	{
	printf("\n\nCalculating sphere volume and surface area...\n");
	sphereVal->volume = ((4/3) * pi * (sphereVal->radius * sphereVal->radius* sphereVal->radius));
	sphereVal->surface_area = (4 * pi * sphereVal->radius * sphereVal->radius);	
	};
void DispSphere (struct sphere *sphereVal)  
	{
	printf("\nDisplaying sphere radius, volume, name, and surface area...\n");
	printf("\n\tRadius: %.3f",sphereVal->radius);
	printf("\n\tVolume: %.3f",sphereVal->volume);
	printf("\n\tName: %s",sphereVal->name);
	printf("\n\tSurface area: %.3f",sphereVal->surface_area);
	printf("   \n");
	};
void SetCube (struct cube *CubeVal)
	{
	printf("\n\nSetting cube side length and name...\n");
	printf("\tPlease enter side length: ");
	scanf("%f",&cubeVal.side);
	printf("\n\tPlease enter name: ");
	scanf("%s",cubeVal.name);
	};
void CalcCube (struct cube *CubeVal)  
	{
	printf("\n\nCalculating cube face area, volume, and surface area...\n");
	cubeVal.face_area = cubeVal.side * cubeVal.side;
	cubeVal.surface_area = cubeVal.face_area * 6;
	cubeVal.volume = pow(cubeVal.side, 3);
	};
void DispCube (struct cube *cubeVal)   
	{
	printf("Displaying cube side length, face area, surface area, volume, and name...\n");
	printf("Side length: %f\n",cubeVal->side);
	printf("Face area: %f\n",cubeVal->face_area);
	printf("Surface area: %f\n",cubeVal->surface_area);
	printf("Volume: %f\n",cubeVal->volume);
	printf("Name: %s",cubeVal->name);
	};
void SetRegtet (struct regtet *regtetVal)   
	{
	printf("\n\nSetting regular tetrahedron parametrs...");
	printf("\nPlease enter a name: ");
	scanf("%s",regtetVal->name);
	printf("\nPlease enter a side length: ");
	scanf("%f",&regtetVal->side);
	};

void CalcRegtet (struct regtet *regtetVal)   
	{
	printf("\n\nCalculating regular tetrahedron face area, surface area, and volume...");
	regtetVal->face_area = 0.5 * regtetVal->side * regtetVal->side;
	regtetVal->surface_area = regtetVal->face_area * 4;
	regtetVal->volume = sqrt(3) * pow(regtetVal->side, 2);
	};
void DispRegtet (struct regtet *regtetVal)
	{
	printf("\n\nDisplaying regular tetrahedron values...\n");
	printf("Side length: %f",regtetVal->side);
	printf("\nFace area: %f",regtetVal->face_area);
	printf("\nSurface area: %f",regtetVal->surface_area);
	printf("\nVolume: %f",regtetVal->volume);
	printf("\nName: %s",regtetVal->name);



/* 
NOTE: A calculation to check one value of each shape was performed in Excel, and all values were found to be correct.
*/
	};
