#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <string.h>
#include <unistd.h>
#include <iostream>
#include <fstream>
using namespace std;

int main()
{

//Printing
cout << "\n************************************************"; 
cout << "\n* Name:     Sean Sullivan       Date: 11/18/19 *"; 
cout << "\n* Seat: 00  File: APP_C35_1.cpp                *"; 
cout << "\n* Instructor:                      Morin 10:20 *"; 
cout << "\n************************************************\n\n";

// Declaring, defining variables and setting the ifstream and ofstream
float gpaClass[9], gpaClassTotal, gpa, gpaHoursTotal, hours[9];
char grade[9];
char className[8][15];
char name[20];
ifstream grades;
ofstream gpaye;
gpaClassTotal = gpaHoursTotal = 0;

//Asking the user to enter the name of the grades file
cout << "Please enter the name of the grades file: ";
cin >> name;

//Opening the input and output files
grades.open(name);
gpaye.open("APP_C35_1_result.txt");

/*
Setting up a for loop that inputs lines of the grades file then switches based on each letter grade.
A calculation is performed for each switch statement, giving the gpa average for that class based
on its hours and letter grade.
*/
for (int i=0; i<8; i++)
	{
	grades >> className[i] >> grade[i] >> hours[i];
	
	switch (grade[i])
		{
		case 'A':
			{
			gpaClass[i] = 4.0 * hours[i];
			break;
			}
		case 'B':
			{
			gpaClass[i] = 3.0 * hours[i];	
			break;
			}
		case 'C':
			{
			gpaClass[i] = 2.0 * hours[i];
			break;
			}
		case 'D':
			{
			gpaClass[i] = 1.0 * hours[i];
			break;
			}		
		case 'E':
			{
			gpaClass[i] = 0.0 * hours[i];
			break;
			}	
		}
			
//Finally this loop is making a summation of the total gpa points and class hours		
	gpaClassTotal += gpaClass[i];
	gpaHoursTotal += hours[i];
	}
	
//Using math to determine the average gpa
gpa = gpaClassTotal / gpaHoursTotal;

//Telling the user the average gpa
cout << "\n\nThe calculated average GPA is " << gpa << endl;
gpaye << "\n\nThe calculated average GPA is " << gpa << endl;

/*
NOTE: This average GPA value was checked by hand and determined to be valid.
*/
}

