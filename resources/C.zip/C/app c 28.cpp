# include <stdio.h>
# include <math.h>

int main()
{
float a, b, c, avg;
float *ptr1, *ptr2, *ptr3, *ptr4; 
ptr1 = &a; 
ptr2 = &b; 
ptr3 = &c; 
ptr4 = &avg;

printf ("\n************************************************");
printf ("\n* Name:     Sean Sullivan       Date: 10/28/19 *");
printf ("\n* Seat: 17  File: APP_C28_1.cpp                *");
printf ("\n* Instructor:                      Morin 10:20 *");
printf ("\n************************************************\n\n");


//Prompting the user for each of three numbers
printf("\nPlease enter three numbers, positive or negative.");
printf("\nPlease enter number 1: ");
scanf("%f",ptr1);
printf("\nPlease enter number 2: ");
scanf("%f",ptr2);
printf("\nPlease enter number 3: ");
scanf("%f",ptr3);

//Computing and printing the average
*ptr4 = (*ptr1 + *ptr2 + *ptr3) / 3;
printf("\n\nThe average of these three numbers is %f.",*ptr4);

//Computing and printing the absolute value
*ptr1 = fabs(*ptr1);
*ptr2 = fabs(*ptr2);
*ptr3 = fabs(*ptr3);
printf("\n\nThe absolute values of your numbers area as follows:\n%f,\n%f,\n%f",*ptr1,*ptr2,*ptr3);

//Computing and printing the average of the absolute values
*ptr4 = (*ptr1 + *ptr2 + *ptr3) / 3;
printf("\nThe average of these three absolute value numbers is %f.",*ptr4);

//Printing the variable and its address
printf("\n\nThe value stored in a is %f, and the address of a is %p.",*ptr1,ptr1);

//Prompting for the 2nd values
printf("\nPlease enter three numbers, positive or negative.");
printf("\nPlease enter number 1: ");
scanf("%f",&a);
printf("\nPlease enter number 2: ");
scanf("%f",&b);
printf("\nPlease enter number 3: ");
scanf("%f",&c);

//Computing and printing the average
avg = (a + b + c) / 3;
printf("\n\nThe average of these three numbers is %f.",avg);

//Computing and printing the absolute value
a = fabs(a);
b = fabs(b);
c = fabs(c);
printf("\n\nThe absolute values of your numbers area as follows:\n%f,\n%f,\n%f",a,b,c);

//Computing and printing the average
avg = (a + b + c) / 3;
printf("\n\nThe average of these three numbers is %f.",avg);

//Printing the variable and its address
printf("\n\nThe value stored in a is %f, and the address of a is %p.",a,&a);


/* 
EVALUATE
- These values were checked by hand and verified to be correct.
- Discussion time! Part A and Part B both end up doing the same math with the same variables, but only Part A involves the use of a pointer. Since they have the same vairables, though, the memory addresses used by both parts are the same. The resulting values may have been different if one entered different numbers at each prompt, but the program was using the same memory addresses across parts.
*/

}
	