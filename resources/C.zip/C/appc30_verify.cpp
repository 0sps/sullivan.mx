/***************************************/
/* Name: Sean Sullivan Date: 10/31/19  */
/* Code: APP C30-1                     */
/***************************************/
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>

int main()
{
	
printf("***************************************\n");
printf("* Name: Sean Sullivan Date:10/29/19   *\n");
printf("* Code: APP C29-1                     *\n");
printf("***************************************\n");
		
//Initializing files
FILE *inpt, *outpt;
int k, i, status, mTotal, cTotal, jTotal, str1len, str2len;
mTotal = cTotal = jTotal = 0;

//Opening the input and output files into file pointers
inpt = fopen("APP_C30_1_programmers.txt","r");
outpt = fopen("APP_C30_1_result.txt","w");

//Defining variables
char engr[30][12];
char lang[30][12];
char mprog[30][12];
char cprog[30][12];
char jprog[30][12];
char combinedString[400];
char combinedString2[400];
char mCheck[] = "MATLAB";
char jCheck[] = "Java";
char cCheck[] = "C/C++";

/* Setting up a for loop to scan in first the engineer's name and then the language */
for (k=0; k<30; k++)
	{
	status = fscanf(inpt,"%s", engr[k]);
	status = fscanf(inpt,"%s", lang[k]);
	}

/* Setting up a for loop to check the type of language and increment the respective counter variable.
This also adds that engineer's name into an array indicating names of similarly specialized 
engineers. */

for (k=0; k<30; k++)
	{
	if (strcmp(lang[k], mCheck) == 0)
		{
		strcpy(mprog[mTotal], engr[k]);
		mTotal++;
		}
	else if (strcmp(lang[k], cCheck) == 0)
		{
		strcpy(cprog[cTotal], engr[k]);
		cTotal++;
		}	
	else if ((strcmp(lang[k], jCheck) == 0))
		{
		strcpy(jprog[jTotal], engr[k]);
		jTotal++;
		}
	}

/* Printing all the specilists using for loops */
printf("\n\nThere are %i MATLAB specialists, %i C/C++ specialists, and %i Java specialists.\n",mTotal,cTotal,jTotal);
printf("\nBelow is a list of MATLAB specialists.");
for (i = 0; i < mTotal; i++)
	{
	printf("\n%s",mprog[i]);
	}
printf("\n\n\nBelow is a list of Java specialists.");
for (i = 0; i < jTotal; i++)
	{
	printf("\n%s",jprog[i]);
	}
printf("\n\n\nBelow is a list of C/C++ specialists.");

for (i = 0; i < cTotal; i++)
	{
	printf("\n%s",cprog[i]);
	}

//Making the combined string of names and printing it
for (i = 0; i < 30; i++)
	{
	strcat(combinedString, engr[i]);
	}
str1len = strlen(combinedString);
printf("\n\n\nBelow is a combined string of all the names. The string has %i characters.\n---\n%s\n---\n", str1len, combinedString);

//Making the combined list of names (with spaces) and printing it
strcat(combinedString2, engr[0]);
for (i = 1; i < 30; i++)
	{
	strcat(combinedString2, " ");
	strcat(combinedString2, engr[i]);
	}
str2len = strlen(combinedString2);
printf("\n\nBelow is a combined string of all the names, separated by one space each. This string has %i characters.\n---\n%s\n---\n", str2len, combinedString2);



/* I know that I did not have to retype ALL my print statements here to print to the file, but I will anyway. */


fprintf(outpt, "\n\nThere are %i MATLAB specialists, %i C/C++ specialists, and %i Java specialists.\n",mTotal,cTotal,jTotal);
fprintf(outpt, "\nBelow is a list of MATLAB specialists.");
for (i = 0; i < mTotal; i++)
	{
	fprintf(outpt, "\n%s", mprog[i]);
	}
fprintf(outpt, "\n\n\nBelow is a list of Java specialists.");
for (i = 0; i < jTotal; i++)
	{
	fprintf(outpt, "\n%s",jprog[i]);
	}
fprintf(outpt, "\n\n\nBelow is a list of C/C++ specialists.");
// This should be "cTotal"
for (i = 0; i < cTotal; i++)
	{
	fprintf(outpt, "\n%s",cprog[i]);
	}

fprintf(outpt, "\n\n\nBelow is a combined string of all the names. The string has %i characters.\n---\n%s\n---\n", str1len, combinedString);
fprintf(outpt, "\n\nBelow is a combined string of all the names, separated by one space each. This string has %i characters.\n---\n%s\n---\n", str2len, combinedString2);

fclose(inpt);
fclose(outpt);

/*
			EVALUATE: The numebr of engineers programming MATLAB was counted by hand to be 10. The number programming in C was counted to be 13. Finally, the number programming in Java was counted to be 7.

*/


}
