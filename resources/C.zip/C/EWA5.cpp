/***************************************************/ 
/*  Name:  Sean Sullivan   Date:  10/18/19         */ 
/*  Seat:  00    File:  EWA_05.cpp                */ 
/*  Instructor:  Morin 10:20                       */
/***************************************************/ 

/* Initializing program by including libraries */
#include  <stdio.h>
#include  <math.h>
int main ( )
{

//Opening the file and assigning it a variable
FILE *outpt;
outpt=fopen("EWA05.txt","w");

//Declaring the initial variables
float a, d, ener, f, supercalifragalisti, prscs, cumd, oxG;

//Defining some initial variables as well
#define stremma_to_oxgang 1/60
#define c_to_tev 26125697.8238
#define lyear_to_parsecs 0.3065945
#define gallonhr_to_meterday 0.090849882

//First print statement
printf ("\n************************************************"); 
printf ("\n* Name:     Sean Sullivan       Date: 10/18/19 *"); 
printf ("\n* Seat: 00  File: EWA_05.cpp                   *"); 
printf ("\n* Instructor:                      Morin 10:20 *"); 
printf ("\n************************************************");

//Asking for input
printf("\nPlease enter:");
printf("\nAn area in stremmas: "); 
scanf("%f",&a);
printf("\nA distance in light years: ");
scanf("%f",&d);
printf("\nAn amount of energy in calories: ");
scanf("%f",&ener);
printf("\nA flowrate in gallons per hour: ");
scanf("%f",&f);


/*   Let's do some  c a l c u l a t i o n s !  */
oxG = a * stremma_to_oxgang;
prscs = d * lyear_to_parsecs;
supercalifragalisti = ener * c_to_tev;
cumd = f * gallonhr_to_meterday;

//Printing the values out to the user
printf("\n\nConversions:");
printf("\n%f stremmas -- %f oxgangs.",a,oxG);
printf("\n%f light years -- %f Parsecs.", d, prscs);
printf("\n%f calories -- %e tetraelectronvolts.", ener, supercalifragalisti);
printf("\n%f US gallons/hour -- %f cubic meters/day.",f, cumd);
printf("\nThis information will also be exported to EWA05.txt.");
fprintf(outpt,"\n\nConversions:\n%f stremmas -- %f oxgangs.\n%f light years -- %f Parsecs.\n%f calories -- %e tetraelectronvolts.\n%f US gallons/hour -- %f cubic meters/day.",a,oxG,d,prscs,ener,supercalifragalisti,f,cumd);
return 0;
}