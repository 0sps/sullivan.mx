#include <stdio.h>
#include <stdlib.h>

//Declare structure Type
struct Type
{
  float Balance;
  int Tcount;
};



//Declare structure Account with alias BankBal
typedef struct Account
{
  long int Account;
  char Name[30];
  float TotalBalance;
  //Include two instances of struct Type (Savings and Checking)
  struct Type Savings;
  struct Type Checking;
} BankBal;

//Create function prototypes for newaccount and transaction
void newaccount (BankBal [], int);
void transaction (struct Type * typ, float amount);
void inquiry (BankBal *);

//Begin main function
int main ( )
{
  printf ("\n************************************************"); 
  printf ("\n* Name:     Sean Sullivan       Date: 11/14/19 *"); 
  printf ("\n* Seat: 00  File: APP_C34_1.cpp                *"); 
  printf ("\n* Instructor:                      Morin 10:20 *"); 
  printf ("\n************************************************\n\n");
  //Declare counter variable, used to tell newaccount which array index you are using
  int i;

  //Create vector BankLand with 2 instances of struct Account
  BankBal BankLand[2];
  
  //Call newaccount to fill in BankLand array
  newaccount(BankLand, 0);
  newaccount(BankLand, 1);
  
  
  //Call transaction to deposit $435.00 into the Savings account of BankLand[0]
  printf("\nDepositing $435.00 into Savings account '%s'.\n",BankLand[0].Name);
  transaction(&BankLand[0].Savings, 435.00);
  
  //Call transaction 6 times,  withdrawing  $58.35 from the Checking account of BankLand[1] in each transaction
  int j;
  for (j=1; j<=6; j++)
    {
      printf("\nWithdrawing $58.35 from Checking account '%s'.\n",BankLand[1].Name);
      transaction(&BankLand[1].Checking, -58.35);
    }

  //Print details of both BankLand accounts to the screen using inquiry function
  inquiry(&BankLand[0]);
  inquiry(&BankLand[1]);
}


//Define function newaccount
void newaccount (BankBal a[], int j)
{
  //Prompt user to input values and use scanf to 
  printf("Enter account number:  ");
  scanf("%ld", &a[j].Account);
  printf("Enter account name:  ");
  scanf("%s", a[j].Name);
  printf("Enter Savings balance:  ");
  scanf("%f",&a[j].Savings.Balance);
  printf("Enter Checking balance:  ");
  scanf("%f",&a[j].Checking.Balance);
  printf("\n\n");

  //Initialize Tcount to zero for both Savings and Checking
    a[j].Savings.Tcount = 0;
    a[j].Checking.Tcount = 0;
  
  //Find total balance
  a[j].TotalBalance = a[j].Savings.Balance + a[j].Checking.Balance;
  
  
  }

//Define function transaction
void transaction (struct Type * typ, float amount)
{
    //BankLand only allows 5 transactions per day per account type (Savings or Checking).  If less than 5 transactions have occured, increment Tcount and perform the transaction.  Otherwise, perform the transaction,  withdraw a penalty of $3.00 from the account, and notify the user of the issue.
 if (typ->Tcount < 5)
    {
      //Add transaction amount to total
      typ->Balance = typ->Balance + amount;
      //Increment Tcount
      typ->Tcount++;
    }
  else 
    { 
      //Add transaction amount to total
      typ->Balance = typ->Balance + amount;
      //Withdraw $3.00 from account
      typ->Balance = typ->Balance - 3;
      //Notify user of issue
      printf("\nMore than 5 transactions have occured today, a $3.00 penalty will be assessed.\n");
    }
}

//Define function inquiry
void inquiry (BankBal * bank)
{
  //Update TotalBalance
  bank->TotalBalance = bank->Savings.Balance + bank->Checking.Balance;

  //Print account details to the screen (Account number, name, total balance, and Savings and Checking balances)
  printf("\nAccount number:\t%ld",bank->Account);
  printf("\nAccount name:\t%s",bank->Name);
  printf("\nTotal Balance:\t%.2f",bank->TotalBalance);
  printf("\nSavings Balance:\t%.2f",bank->Savings.Balance);
  printf("\nChecking Balance:\t%.2f",bank->Checking.Balance);
  printf("\n");
  
  /*
        EVALUATE
        These values were checked in Excel, and verified to be correct.
          
          
          
          ---THIS IS THE END OF THE CODE FILE---
  */
  
}
