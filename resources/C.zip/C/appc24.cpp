/***************************************************/ 
/*  Name:  Sean Sullivan   Date:  10/17/19         */ 
/*  Seat:  00    File:  APP_C24.cpp                */ 
/*  Instructor:  Morin 10:20                       */
/***************************************************/ 

/* Initializing program by including libraries */
#include  <stdio.h>
#include  <math.h>
int main ( )
{

//Opening the file and assigning it a variable
FILE *outpt;
outpt=fopen("APP_C_24_1_results.txt","w");

//Declaring the initial variables

float acre, ha, mi, ft, yd, m, in;

printf ("\n************************************************"); 
printf ("\n* Name:     Sean Sullivan       Date: 10/17/19 *"); 
printf ("\n* Seat: 00  File: APP_C24.cpp                  *"); 
printf ("\n* Instructor:                      Morin 10:20 *"); 
printf ("\n************************************************");

// Getting initial area 
printf("\nPleae enter the area in acres: \n");
scanf("%f", &acre);

/* Computing necessary calculations to convert areas */
ha=acre/2.47105;
mi=acre/640;
ft=acre*43560;
yd=acre*4840;
m=acre*4046.86;
in=acre*6.273e6;

//Printing the new areas. Once to the user, and once to the file
printf("\nThe new areas are as follows:\n%f hectares,\n%f square miles,\n%f square feet,\n%f square yards,\n%f square meters,\nand %f square inches. \nThis information has also been printed to APP_C_24_1_results.txt, and verified by Excel.", ha, mi, ft, yd, m, in);
fprintf(outpt,"The original area was %f acres.\n\nThe new areas are as follows:\n%f hectares,\n%f square miles,\n%f square feet,\n%f square yards,\n%f square meters,\nand %f square inches.", acre, ha, mi, ft, yd, m, in);

// These values were verified in Excel.
return 0;
}
