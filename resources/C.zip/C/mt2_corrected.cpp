// ENGR 1281.0xH Midterm 2, November 4, 2019
// Seed File - C/C++ Programming
// Set up needed #includes and #defines.
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <string.h>
#include <unistd.h>
using namespace std;

int main()
{
FILE *inpt;
FILE *outpt;
//Declaring variables
int count = 0;
int st = 0;
int prodNumMax = 0;
int priceMax = 0;
int priceMaxIndex = 0;
int prodNumMaxIndex = 0;
char c;
int siz = 0;
float prices[500];
int lines[500];
int status = 1;
int prodNum[500];

//opening the input file into an input pointer, and doing the same for the output file
inpt = fopen("C_A_PRODUCTS.txt","r");
outpt = fopen("C_A_RESULTS.txt","w");
//Print statements

printf("\n***************************************************\n");
printf("* NAME: Sean Sullivan DATE: 11/04/2019 *\n");
printf("* SEAT: 0 FILE: C_A_INVENTORY.cpp *\n");
printf("* INSTRUCTOR: Morin HOUR: 15:00 *\n");
printf("*****************************************************\n");
//Checking if the file opened successufly

if (inpt == NULL)
		{
		printf("\nFailed to open file.\n");
		return 0;
		}
	else
		{
		printf("\nFile opened successfully.\n");
		}
		

//Finding how many lines this data file has, reading in variables
while (!feof(inpt))
	{
	status = fscanf(inpt,"%i%f",&prodNum[siz],&prices[siz]);
	siz++;
	}
//Correcting the amount of lines we will read if we have over 500
if (siz > 500)
	{
	siz = 500;
	}
//Determining maximum prices and corresponding product #
//Using a variables called checkPrice that is used to see which products are 1.99$.
float checkPrice = 1.99;
for (int i=0; i<siz; i++)
{	
	if (prices[i] == checkPrice)
		{
		priceMaxIndex++;
		}
	if (prices[i] >= prices[priceMax])
		{
		priceMax = i;
		}
}
printf("\nThere are a total of %i products with a cost of $1.99. \nProduct number %i has the largest price at %f.",priceMaxIndex,prodNum[priceMax],prices[priceMax]);
fflush(stdout);
//Printing to the file
//Print statements
fprintf(outpt,"\n***************************************************\n");
fprintf(outpt,"* NAME: Sean Sullivan DATE: 11/04/2019 *\n");
fprintf(outpt,"* SEAT: 0 FILE: C_A_INVENTORY.cpp *\n");
fprintf(outpt,"* INSTRUCTOR: Morin HOUR: 15:00 *\n");
fprintf(outpt,"*****************************************************\n");
fprintf(outpt,"\nThere are a total of %i products with a cost of $1.99\n Product number %i has the largest price at $%f.",priceMaxIndex,prodNum[priceMax],prices[priceMax]);
fflush(outpt);

//closing files
fclose(inpt);
fclose(outpt);

}