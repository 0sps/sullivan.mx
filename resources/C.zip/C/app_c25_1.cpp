/***************************************************/ 
/*  Name:  Sean Sullivan   Date:  10/21/19         */ 
/*  Seat:  00    File:  APP_C25_1.cpp              */ 
/*  Instructor:  Morin 10:20                       */
/***************************************************/ 

/* Initializing program by including libraries */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
int main (void)
{

//Declaring variables
int x;
int y;
int resp;
int answer;
int response;
int totalRight;
int totalWrong;
int totalPlayed;

//First print statement
printf ("\n************************************************"); 
printf ("\n* Name:     Sean Sullivan       Date: 10/21/19 *"); 
printf ("\n* Seat: 00  File: APP_C25_1.cpp                *"); 
printf ("\n* Instructor:                      Morin 10:20 *"); 
printf ("\n************************************************");

//Starting the multiplication test, and adding a goto line reference
play:
printf ("\n\nThis is a multiplication test. Here are two numbers between 1 and 12:\n");
//Let's get these random values 
srand(time(NULL)); 
x = (rand() % 12)+1;
y = (rand() % 12)+1;
printf("The numbers are %i and %i. Try to multiply them in your head and enter the answer below.\n\n=",x,y);

//Collecting user response
scanf("%i",&resp);

/* Computing answer, checking it against user's entry, and letting them know if correct/incorrect. Also tallying variables that have overall score. */
answer = x * y;
if (resp == answer)
{	printf("\nCorrect!");
	totalRight++;
	totalPlayed++;
}
else 
{ 
	printf("\nIncorrect. The correct answer was %i.",answer);	
	totalWrong++;
	totalPlayed++;
}

//Seeing what they want to do and using appropriate goto statements.
//In this context, "choice" below represents a goto line
choice:
printf("\nPlease choose one of the following selections:\n (1) Play again\n (2) See statistics\n (3) Reset statistics\n (4) Quit\n");
scanf("\n%i",&response);

switch (response)
{
	case 1:
	{
		goto play;
	}
	case 2:
	{
		printf("\nYou solved %i problems, getting %i right and %i wrong.",totalPlayed,totalRight,totalWrong);
		goto choice;
	}
	case 3:
	{
		totalPlayed = totalWrong = totalRight = 0;
		printf("\nStatistics reset.");
		goto choice;
	}
	case 4:
		{goto end;}
	default: 
		{	
		printf("\n --- Your entry was not understood. ---\n");
		goto choice;
		
		}
}
end:
return 0;

}